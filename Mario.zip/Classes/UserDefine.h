#pragma once

#define D_DESIGN_WIDTH 16*16
#define D_DESIGN_HEIGHT 16*15

#define MAP_HEIGHT 15
#define MAP_WIDTH 224

#define D_WINDOWS_SHOW 2.0

#define OVER Vec2(8000,8000)

#define D_GAME_NAME "My Game"