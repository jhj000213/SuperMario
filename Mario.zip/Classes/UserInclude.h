#pragma once

#include "cocos2d.h"
#include "AudioEngine.h"
#include <vector>
#include <map>
#include <math.h>
#include <algorithm>
#include <stdlib.h>
#include <time.h>
#include <random>

USING_NS_CC;
using namespace std;
using namespace experimental;
#include "Star.h"
#include "M_Gumba.h"
#include "M_Tuttle.h"
#include "Flower.h"
#include "Mush.h"
#include "Camera.h"
#include "Block.h"
#include "Fire.h"
#include "Mario.h"




#include "AppDelegate.h"

#include "GameScene.h"